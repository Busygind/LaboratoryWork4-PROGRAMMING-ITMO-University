package utilities;

public interface ObjectInterface {
    String getName();
}
