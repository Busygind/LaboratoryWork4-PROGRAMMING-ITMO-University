package utilities;

public interface Observable extends ObjectInterface {
	void observedBy (Person person);
}